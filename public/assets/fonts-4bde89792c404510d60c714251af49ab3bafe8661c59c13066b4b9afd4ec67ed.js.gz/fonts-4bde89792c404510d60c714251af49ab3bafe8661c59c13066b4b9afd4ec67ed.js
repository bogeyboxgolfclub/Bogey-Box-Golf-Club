<script>
  WebFont.load({
    google: {
      families: ["Merriweather:300,400,700,900","Abril Fatface:regular","Raleway:100,200,300,regular,500,600,700,800,900","Merriweather Sans:300,300italic,regular,italic,700,700italic,800"]
    }
  });
</script>
